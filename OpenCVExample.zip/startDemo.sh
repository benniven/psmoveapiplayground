#/bin/sh
LD_LIBRARY_PATH=./lib
export LD_LIBRARY_PATH
"./Debug(LINUX)/OpenCVExample"
